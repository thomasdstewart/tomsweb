<?php include("site.php"); ?>
<?php sitehead("DDS Tape Destruction"); ?>
<h2>Intro</h2>
        <p>To see how hardy dds tapes were, I decided to do some tests. I apologise for the image quality. Anyway, on with the show</p>
        <h2>DDS Tape</h2>
        <p>A plain old DDS 4 tape, 20G native, 40G compressed</p>
        <img src="images/ddstape.jpg" alt="dds tape" />
        <h2>DDS Tape - After Test</h2>
        <p>My main test was to see how strong the cassettes actually are, so I decided to run one over with my car. Three times.</p>
        <p>Surprisingly the only thing to break was the case and the flap at the front, the main part stayed intact. I only rolled over it, I'd say if I hit it at speed, it would be toast.</p>
        <p><img src="images/ddstapeafter1.jpg" alt="broken dds tape" /></p>
        <p><img src="images/ddstapeafter2.jpg" alt="broken dds tape" /></p>
        <p><img src="images/ddstapecomp.jpg" alt="dds tape comparison" /></p>

<?php sitefoot(); ?>
