<?php include("site.php"); ?>
<?php sitehead("Debian"); ?>

<p>To get nice debian package of the oracle instant client do the following (beware, im so not a debian packager)</p>
<ul>
<li>unzip instantclient-basic-linux32-10.2.0.1-20050713.zip</li>
<li>unzip instantclient-jdbc-linux32-10.2.0.1-20050713.zip</li>
<li>unzip instantclient-odbc-linux32-10.2.0.1-20050713.zip</li>
<li>unzip instantclient-sdk-linux32-10.2.0.1-20050713.zip</li>
<li>unzip instantclient-sqlplus-linux32-10.2.0.1-20050713.zip</li>
<li>mv instantclient_10_2 oracle-instantclient_10.2.0.1-20050713</li>
<li>tar cvzf oracle-instantclient_10.2.0.1-20050713.orig.tar.gz oracle-instantclient_10.2.0.1-20050713</li>
<li>rm -r -f oracle-instantclient_10.2.0.1-20050713</li>
</ul>

<ul>
<li>wget http://www.stewarts.org.uk/debian/oracle-instantclient_10.2.0.1-20050713-1.dsc</li>
<li>wget http://www.stewarts.org.uk/debian/oracle-instantclient_10.2.0.1-20050713-1.diff.gz</li>
</ul>

<ul>
<li>dpkg-source -x oracle-instantclient_10.2.0.1-20050713-1.dsc</li>
<li>cd oracle-instantclient-10.2.0.1-20050713</li>
<li>dpkg-buildpackage -b -rfakeroot -us -uc</li>
<li>sudo dpkg -i ../oracle-instantclient_10.2.0.1-20050713-1_i386.deb</li>
</ul>

<?php sitefoot(); ?>
