Format: 1.0
Source: mdxvu
Version: 0.96-20060707-1
Binary: mdxvu
Maintainer: Thomas Stewart <thomas@stewarts.org.uk>
Architecture: any
Standards-Version: 3.6.1
Build-Depends: debhelper (>= 4.0.0)
Files: 
 e04a97d8b7eeb3f50ca522755bd8aebe 1660388 mdxvu_0.96-20060707-1.tar.gz
