Format: 1.0
Source: oracle-instantclient
Version: 10.2.0.1-20050713-1
Binary: oracle-instantclient
Maintainer: Thomas Stewart <thomas@stewarts.org.uk>
Architecture: i386
Standards-Version: 3.6.2
Build-Depends: cdbs (>= 0.4.23-1.1), debhelper (>= 4.0.0)
Files: 
 4bd9831556cf5b982498a2d901a02f13 36881804 oracle-instantclient_10.2.0.1-20050713.orig.tar.gz
 5f57356e2ab16a4f8066433ce7e271c7 5890 oracle-instantclient_10.2.0.1-20050713-1.diff.gz
