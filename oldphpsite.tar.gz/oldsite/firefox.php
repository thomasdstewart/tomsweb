<?php include("site.php"); ?>
<?php sitehead("Firefox"); ?>
        <p><a href="http://www.mozilla.org/projects/firefox/">Firefox</a> is great!. Here is the <a href="stuff/user.js">user.js</a> that I maintain:</p> 
        <pre><?php include("stuff/user.js"); ?></pre>
<?php sitefoot(); ?>
