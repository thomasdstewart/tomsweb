<?php include("site.php"); ?>
<?php sitehead("Greasemonkey"); ?>
        <p><a href="http://greasemonkey.mozdev.org/">Greasemonkey</a> is a Firefox extention that lets you edit the DOM (ie the page) on the fly after the page is downloaded and parsed, but before it is rendered. Thus making it very easy to tweak pages slightly. For example it could search text for text that starts with http:// but is not a link, and replace the text with a link to the location. This provides a very powerfull way to edit web pages on the fly.</p>
        <p><a href="http://diveintogreasemonkey.org/">Dive Into Greasemonkey</a> is an exelent guide for greasemonkey. It covers installing it all the way to very complex examples.</p>
        <p>In the start most people added their scripts to a <a href="http://dunck.us/collab/GreaseMonkeyUserScripts">Wiki</a>. This soon exploded with user contributed scipts, hundereds of them. This soon grew very big, fortunatly help was at hand and <a href="http://userscripts.org/">userscripts.org</a> was created. It is a much better reposiraty
<?php sitefoot(); ?>
