<?php include("site.php"); ?>
<?php sitehead("The Hen"); ?>
        <img src="images/hen.jpg" alt="Hen" />
<?php sitefoot(); ?>
