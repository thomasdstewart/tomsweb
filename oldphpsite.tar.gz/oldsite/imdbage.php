<?php include("site.php"); ?>
<?php sitehead("IMDB Age"); ?>
        <h2>IMDB Age</h2>
        <p>IMDB Age is a <a href="greasemonkey.php">greasemonkey</a> script that I wrote. This script adds the age of an actor or actress, their Tropical Zodiac Sign and their Chinese Zodiac Sign on their IMDB page. It also adds how long ago the film was made. </p> 
        <p>I have made two screenshots <a href="stuff/IMDBAge1.png">1</a> <a href="stuff/IMDBAge2.png">2</a> so you can see what it looks like.</p>
        <p>It was was created on 2005-03-29 but inspired sometime in 2001 and the last modification was on 2005-09-16. And the current version is v2.1. First you need greasmonkey installed then, follow <a href="stuff/IMDBAge.user.js">this</a> link and select "Install User Script" from tools menu. </p>
<?php sitefoot(); ?>
