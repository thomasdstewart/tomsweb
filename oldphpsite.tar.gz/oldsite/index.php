<?php include("site.php"); ?>
<?php sitehead(""); ?>
        <h2>Amazon</h2>
        <a href="http://www.amazon.co.uk/exec/obidos/registry/EI6DFQ4KYJZW">Amazon Wish List</a>
        <h2>Money</h2>
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
        <input type="hidden" name="cmd" value="_xclick"/>
        <input type="hidden" name="business" value="thomas@stewarts.org.uk"/>
        <input type="hidden" name="item_name" value="Thomas back pocket"/>
        <input type="hidden" name="item_number" value="appreciators"/>
        <input type="hidden" name="no_note" value="1"/>
        <input type="hidden" name="currency_code" value="EUR"/>
        <input type="hidden" name="tax" value="0"/>
        <input type="image" src="https://www.paypal.com/images/x-click-but04.gif" name="submit" alt="PayPal Donate"/>
        <p>Do not send me money, this is merly a demonstration of how tacky it is when people put paypal donate buttons on their websites!</p>
        </form>
        <h2>GPG</h2>
        <p>ID: 0x68A70C48<br/>
        Fingerprint: DCCD 7DCB A74A 3E3B 60D5  DF4C FC1D 1ECA 68A7 0C48<br/>
        <a href="stuff/public-key.asc">Public Key</a></p>
        <h2>Geek Code</h2>
        <pre><?php include("stuff/geekcode"); ?></pre>
<?php sitefoot(); ?>
