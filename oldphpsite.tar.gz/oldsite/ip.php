<?php
if(isset($_SERVER["REMOTE_ADDR"])) {
        print $_SERVER["REMOTE_ADDR"];
}
?>
