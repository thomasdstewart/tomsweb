<?php include("site.php"); ?>
<?php sitehead("Usefull Linux Stuff"); ?>
        <h2>Distros</h2>
        <p>The one true <a href="http://www.debian.org">distribution</a></p>
        <h2>QoS</h2>
        <p>Here is the <a href="stuff/wshaper">script</a> I use to shape traffic on my firewall, a hightly modifyed version of the <a href="http://lartc.org/wondershaper/">Wonder Shaper</a></p>
        <h2>Backup</h2>
        <p>I own a SCSI <a href="http://h18006.www1.hp.com/products/storageworks/dat40/index.html">DAT Drive</a>, here is the <a href="stuff/backup">script</a> I use to do my backups.</p>
        <h2>The Fine Art of Playlists</h2>
        <p>I make my xmms playlist with <a href="stuff/mkplaylist">mkplaylist</a>. You will have to edit the scrip to make it work, change $base to the base dir for all yoru mp3s. Then make new makeplaylist entries, each one is for each playlist, the makeplaylist function takes directories as parameters and it recurses into them and writes a playlist to the right file. It even writes the extended information.</p>
        <a href="#mdstat" name="mdstat"></a><h2>/proc/mdstat information</h2>
        <p>Linux has a software raid subsystem and its called md. It is genrally quite well documented. However the md status file in the proc pseudo filesystem is not documented at all. So this is one of those cases where you have to read the source to understand whats going on. I'll jump right in, this is what my mdstat looks like:-</p>
        <pre>
$ cat /proc/mdstat
Personalities : [raid1]
md1 : active raid1 hde2[0] hdg2[1]
        224187008 blocks [2/2] [UU]

md0 : active raid1 hde1[0] hdg1[1]
        20008832 blocks [2/2] [UU]

unused devices: &lt; none &gt;
$
        </pre>
        <ul>
        <li>The first line is just a list of personalities that the kernel supports, and by personalities it means what raid methods are avalable. If md is compiled into the kernel this list will be static, but if md is compiled as modules the list can change as you insert the various modules. The avalable personalities in linux at the moment are linear, raid0, raid1, raid5 and raid6.</li>
        <li>The file then consistes of a number of stanzas, where each one represents each md device. This the example md0 and md1 are shown.</li>
        <li>The array can then be either "active" or "inactive". For instance if its raid1 it can be active with one block device, where as if its raid0 and the array consts of two devices it will be inactive if onle one is added. It can also have a "read-only" attribute</li>
        <li>In md0 section in this example the "raid1" signifies what personality the array is</li>
        <li>Next is the complete list of block devices that make up the array, in square brackests is the device number in the arrays superblock. There can also be an optionable (F) next to the device, this signifies the device has failed.</li>
        <li>The first thing on the next line if the arrays size in blocks.</li>
        <li>The rest of the line is personality dependant, for linear and raid0 it just shows the rounding in k and the chunk_size in k respectfully. When using raid1 you get more usefull information. First is a set of square brackets with 2 numbers in. The first number is the number of devices in the mirror and the second number is the number of working devices. Next is another set of square brackets, this time each charicter represents a block device. If the characted is a "U" then the devices is up to date, however if the character is a "_" the devices is not uptodate. Raid5 and raid6 are similar but I cant test that.</li>
        <li>If the array has an avalable device that needs to sync, then more lines apper, if not then the stanza finishes. Linux is clever about syncing devices, it does not interupt normal operation or impact on performance. If arrays are on the same device it will only sync them one at a time. And for this reason "resync=DELAYED" appears when teh array is queued for a sync. If the device happens to be resyncing there is a little progress bar, an eta and a speed. As a side note if you reboot before teh sync is done, it is just started form scratch again on teh next boot.</li>
        </ul>
        <p>A little scary, but this is what a mdstat look like when there are filed devices:-</p>
        <pre>
$ cat /proc/mdstat
Personalities : [raid1]
md2 : active raid1 hde1[0] hdi1[1]
        244195904 blocks [2/2] [UU]

md1 : active raid1 hda2[0]
        2168704 blocks [2/1] [U_]

md0 : active raid1 hda1[0]
        7823552 blocks [2/1] [U_]

unused devices: &lt; none &gt;
$
        </pre>
        <p>This is less scary, this is sample output when an array is syncing</p>
        <pre>
Personalities : [raid1]
md1 : active raid1 sdb3[2] sda3[0]
      214178496 blocks [2/1] [U_]
        resync=DELAYED
md0 : active raid1 sdb2[2] sda2[0]
      20008832 blocks [2/1] [U_]
      [==>..................]  recovery = 13.6% (2728704/20008832) finish=9.5min speed=30003K/sec
unused devices: <none>
        </pre>
        <p>this is whats spat to syslog</p>
        <pre>
Feb 17 19:13:49 localhost kernel: md: trying to hot-add unknown-block(22,1) to md0 ...
Feb 17 19:13:49 localhost kernel: md: bind<hdc1>
Feb 17 19:13:49 localhost kernel: RAID1 conf printout:
Feb 17 19:13:49 localhost kernel:  --- wd:1 rd:2
Feb 17 19:13:49 localhost kernel:  disk 0, wo:0, o:1, dev:hda1
Feb 17 19:13:49 localhost kernel:  disk 1, wo:1, o:1, dev:hdc1
Feb 17 19:13:49 localhost kernel: md: syncing RAID array md0
Feb 17 19:13:49 localhost kernel: md: minimum _guaranteed_ reconstruction speed: 1000 KB/sec/disc.
Feb 17 19:13:49 localhost kernel: md: using maximum available idle IO bandwith (but not more than 200000 KB/sec) for reconstruction.
Feb 17 19:13:49 localhost kernel: md: using 128k window, over a total of 15007488 blocks.
Feb 17 19:26:15 localhost kernel: md: md0: sync done.
Feb 17 19:26:15 localhost kernel: RAID1 conf printout:
Feb 17 19:26:15 localhost kernel:  --- wd:2 rd:2
Feb 17 19:26:15 localhost kernel:  disk 0, wo:0, o:1, dev:hda1
Feb 17 19:26:15 localhost kernel:  disk 1, wo:0, o:1, dev:hdc1
</pre>
<?php sitefoot(); ?>
