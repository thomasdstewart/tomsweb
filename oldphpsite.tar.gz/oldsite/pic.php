<?php
        /* no more comments sam!! */
	function is_image ($f) {
		return is_file ($f)
			&& is_readable ($f)
			&& preg_match ('/^image\//', mime_content_type ($f));
	}

	function is_index_image ($f) {
		return is_image ($f)
			&& is_image (dirname($f) . "/thumb/" . basename($f));
	}

	function file_thumb ($f) {
                return dirname($f) . "/thumb/" . basename($f);
	}

	function file_title ($f) {
		if (is_file ($f))
			return substr (basename($f), 0, -strlen (strchr (basename($f), '.')));
		else
			return basename($f);
	}

	function file_text ($f) {
		if (is_file ($f))
			$source = "$f.text";
		else
			$source = "$f/text";

		if (file_exists ($source))
			return file_get_contents ($source);
		else
			return '(no description)';
	}

	function scandir2 ($d) {
		$r = array ();

		$dh = opendir ($d);
		while (($f = readdir ($dh)) !== false)
			array_push ($r, $d . $f);
		closedir ($dh);
		
		return $r;
	}

        if(isset($_REQUEST["set"]) && ereg('^(ski|ski08a|live8|glass|car)$', $_REQUEST["set"]))
                $set = $_REQUEST["set"];
        else
                $set = "";

        $files = scandir2 ("pic/" . $set . "/");
	$files = array_filter ($files, create_function ('$f', 'return is_index_image ($f);'));
?>

<?php include("site.php"); ?>
<?php sitehead($set . " - Pictures"); ?>

	<?php echo file_text("pic/" . $set . "/") ?>

	<table style='border: none'>
		<?php foreach ($files as $f) { ?>
                <tr>
			<td style='border: none'>
				<a href='<?php echo $f ?>'>
				<img src='<?php echo file_thumb($f) ?>' alt='<?php echo basename($f) ?>'/>
				</a>
			</td>
			<td style='border: none'>
				<h2><?php echo file_title ($f) ?></h2>
				<?php echo file_text ($f) ?>
			</td>
                </tr>
		<?php } ?>
	</table>

<?php sitefoot(); ?>
