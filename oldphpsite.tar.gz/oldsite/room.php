<?php include("site.php"); ?>
<?php sitehead("My Room"); ?>
<?php
        if(isset($_REQUEST["dir"]) && ereg('^[0-9]$', $_REQUEST["dir"]))
                $dir = $_REQUEST["dir"];
        else
                $dir = 0;

        $left = $dir - 1;
        $right = $dir + 1;
        if($left < 0)
                $left = 6;
        if($right > 6)
                $right = 0;
?>

        <h2><a href="room.php?dir=<?php echo $left; ?>"><- </a>
        <a href="room.php?dir=<?php echo $right; ?>">-></a></h2>
        <img src="images/room<?php echo $dir; ?>.jpg" alt="room" />

<?php sitefoot(); ?>
