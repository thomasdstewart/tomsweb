<?php
function sitehead($title) {
        if($title == "")
                $title = "Toms Web";
        else 
                $title = "$title";

        ?>
<?php header('Content-type: application/xhtml+xml'); echo '<?xml version="1.0" ?>'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
        <head>
                <title><?php echo $title;?></title>
                <meta name="generator" content="Toms Web"/>
                <meta name="keywords" content="firefox, linux, greasemonkey, vim, imdb" />
                <meta name="description" content="Toms random stuff page" />
                <meta http-equiv="Content-Type" content="text/html; charset=us-ascii" />
                <link rel="stylesheet" href="styletest.css" />
                <link rel="icon" href="images/icon.png" type="image/png" />
        </head>
        <body>
                <div id="menu">
                        <a href="index.php"><img src="images/logo.png" alt="logo"/></a>
                        <ul>
                                <li>Movie Log
                                        <ul>
                                        <li><a href="movielog.php">Latest 3</a></li>
                                        <li><a href="movielog.php">Archive</a></li>
                                        </ul>
                                </li>
                                <li>Geeky
                                        <ul>
                                        <li><a href="firefox.php">Firefox</a></li>
                                        <li><a href="linux.php">Linux</a></li>
                                        <li><a href="vim.php">Vim</a></li>
                                        <li><a href="greasemonkey.php">Greasemonkey</a></li>
                                        <li><a href="imdbage.php">IMDB Age</a></li>
                                        </ul>
                                </li>
                                <li>Random
                                        <ul>
                                        <li><a href="dds.php">DDS Destruction</a></li>
                                        <li><a href="hen.php">The Hen</a></li>
                                        <li><a href="room.php">My Room</a></li>
                                        </ul>
                                </li>
                                <li>Stuff
                                        <ul>
                                        <li><a href="stuff/">Stuff</a></li>
                                        <li><a href="private/">Private</a></li>
                                        </ul>
                                </li>
                                <li>Pictures
                                        <ul>
                                        <li><a href="pic.php?set=ski">Ski in Bulgaria</a></li>
                                        <li><a href="pic.php?set=live8">Live 8</a></li>
                                        </ul>
                                </li>
                                <li>Linkage
                                        <ul>
                                        <li><a href="http://www.robots.org.uk/">robots.org.uk</a></li>
                                        <li><a href="http://www.steev.org.uk/">steev.org.uk</a></li>
                                        <li><a href="http://ue.eu.int/">The Banana republic</a><a href="http://www.google.com/search?q=%22The%20Banana%20republic%22">(Google)</a></li>
                                        </ul>
                                </li>
                        </ul>
                </div>
                <div id="body">
                <h1><?php echo $title;?></h1>
        <?php
}

function sitefoot() {
        ?>      </div>
                <div id="foot">
                        <p>Copyright <a href="mailto:thomasATstewarts@org@uk?subject=Toms Web">Thomas Stewart</a></p>
                        <p><a href="http://validator.w3.org/check/referer">
                        <img src="http://www.w3.org/Icons/valid-xhtml11" alt="Valid XHTML 1.0!" /></a>
                        <a href="http://jigsaw.w3.org/css-validator/">
                        <img src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Valid CSS!" /></a>
                        </p>
                </div>
        </body>
</html>

        <?php
}
