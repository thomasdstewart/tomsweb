<?php include("site.php"); ?>
<?php sitehead("Vim"); ?>
        <p><a href="http://www.vim.org/">Vim</a> is a good text editor my <a href="stuff/vimrc">vimrc</a> is avalable. It's also listed here:</p>
        <pre><?php include("stuff/vimrc"); ?></pre>
<?php sitefoot(); ?>
